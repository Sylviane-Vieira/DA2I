package image;

public class ImagesIncompatiblesException extends Exception {
    public ImagesIncompatiblesException (String msg) {
	     super(msg);
    }
}
