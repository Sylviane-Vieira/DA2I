package animaux;

public class UniciteDuPhenixException extends Exception{
  public UniciteDuPhenixException (String msg) {
     super(msg);
  }
}
