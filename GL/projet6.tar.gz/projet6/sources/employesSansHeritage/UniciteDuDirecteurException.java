package employesSansHeritage;

public class UniciteDuDirecteurException extends Exception{
  public UniciteDuDirecteurException (String msg) {
     super(msg);
  }
}
