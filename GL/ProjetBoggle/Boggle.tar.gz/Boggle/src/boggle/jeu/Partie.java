package boggle.jeu;

import java.nio.file.Path;
import java.util.Iterator;
import java.util.Observable;

import boggle.BoggleException;
import boggle.jeu.Regles.Regle;
import boggle.mots.ArbreLexical;
import boggle.mots.De;
import boggle.mots.Grille;
import boggle.mots.GrilleLettres;

/**
 * Représentation d'une partie générique de Boggle entre plusieurs joueurs.
 * 
 * Note :
 * - si le score à atteindre est inférieur ou égal à 0, la partie s'arrête quand le dernier tour est passé
 * - si le tour maximal atteignable est inférieur ou égal 0, la partie s'arrête quand le score à atteindre est passé
 */
public class Partie extends Observable implements Iterable<Joueur>, Runnable {
	
	private Regles regles;
	private ArbreLexical arbre;
	private Grille grille;
	private Sablier sablier;
	private Joueur[] joueurs;
	private Classement classement;
	private boolean forcerArret;
	private boolean gagnant;
	private int tour;
	
	// Le joueur courant dans la partie
	private Joueur joueur;
	
	public Partie(Regles regles, Joueur[] joueurs) {
		if (regles.getInt(Regle.SCORE_CIBLE) == -1 && regles.getInt(Regle.TOUR_MAX) == -1) {
			throw new BoggleException("Il n'est pas possible d'avoir à la fois un score cible et un tour maximal infinis");
		}
		Path cheminDes = Regles.CONFIG_FOLDER.resolve(regles.getString(Regle.FICHIER_DES));
		Path cheminDico = Regles.CONFIG_FOLDER.resolve(regles.getString(Regle.FICHIER_DICO));
		this.regles = regles;
		this.grille = new GrilleLettres(regles.getInt(Regle.TAILLE_MIN) + 1, De.creerDes(cheminDes));
		this.arbre = ArbreLexical.lireMots(cheminDico);
		this.joueurs = joueurs;
		this.gagnant = false;
		this.forcerArret = false;
		this.tour = 1;
		this.sablier = new Sablier(regles.getInt(Regle.DUREE_SABLIER));
		this.classement = new Classement("Grille " + grille.dimension() + "x" + grille.dimension(), joueurs);
	}
	

	public Grille getGrille() {
		return grille;
	}
	
	public ArbreLexical getDictionnaire() {
		return arbre;
	}
	

	public int[] getPoints() {
		return regles.getIntArray(Regle.POINTS);
	}

	public int getScoreCible() {
		return regles.getInt(Regle.SCORE_CIBLE);
	}
	
	public int getTourMax() {
		return regles.getInt(Regle.TOUR_MAX);
	}

	public Sablier getSablier() {
		return sablier;
	}

	public int tour() {
		return tour;
	}

	public void resetTour() {
		tour = 0;
	}
	
	public void incTour() {
		tour++;
	}

	public boolean estTerminee() {
		return forcerArret || tour == getTourMax() + 1 || gagnant;
	}

	public void forcerArret() {
		forcerArret = true;
		stopperSablier();
	}

	public Joueur getJoueurCourant() {
		return joueur;
	}

	public Joueur[] getJoueurs() {
		return joueurs;
	}

	public Iterator<Joueur> iterator() {
		return new JoueurIterator();
	}
	
	public boolean verifierMot(String mot) {
		return arbre.contient(mot);
	}

	public void terminerTour(Joueur joueur) {
		int taille;
		int pt;
		int min = grille.tailleMinimale();
		int[] points = getPoints();
		for (String mot : grille.getMots()) {
			taille = mot.length();
			if (taille >= min && verifierMot(mot)) {
				if (taille - min < points.length) {
					pt = points[taille - min];
				}
				else {
					pt = points[points.length - 1];
				}
				joueur.incScore(pt);
			}
		}
	}

	public Classement getClassement() {
		return classement;
	}

	//Gère l'alternance des joueurs, et contrôle la partie
	public void run() {
		Iterator<Joueur> it = iterator();
		Joueur meilleur = null;
		
		while (!estTerminee()) {
			for (int i=0; !estTerminee() && i < joueurs.length; i++) {
				grille.secouer();
				joueur = it.next();
				update();
				joueur.joue(grille, arbre, this);
				demarrerSablier();
				terminerTour(joueur);
				if (meilleur == null || meilleur.getScore() < joueur.getScore()) {
					meilleur = joueur;
				}
				gagnant = (getScoreCible() > 0 && meilleur.getScore() >= getScoreCible());
			}
			incTour();
		}
		grille.rendreTout();
		update();
	}
	
	public void demarrerSablier() {
		sablier.reset();
		sablier.run();
	}

	public void stopperSablier() {
		if (!sablier.isOver()) {
			sablier.shutdown();
		}
	}
	
	// Notifie aux observeurs que la partie a changé
	private void update() {
		setChanged();
		notifyObservers();
	}
	
	/**
	 * Implémentation d'un iterateur sur les joueurs.
	 */
	private class JoueurIterator implements Iterator<Joueur> {
		
		private int i = -1;
		
		/**
		 * Retourne toujours vrai tant qu'il y a des joueurs dans la partie
		 */
		public boolean hasNext() {
			return joueurs.length > 0;
		}
		
		/**
		 * Retourne le joueur succédant au joueur courant.
		 * Dans le cas du "dernier" joueur, on retourne au premier.
		 */
		public Joueur next() {
			return joueurs[++i % joueurs.length];
		}

		public void remove() {}
		
	}

}
