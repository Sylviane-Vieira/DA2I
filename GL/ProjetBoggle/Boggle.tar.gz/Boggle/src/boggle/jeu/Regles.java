package boggle.jeu;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Properties;

import boggle.BoggleException;


public class Regles implements Cloneable {
	
	public static final Path CONFIG_FOLDER = Paths.get("config");
	public static final int DEFAULT_TAILLE_MIN = 3;
	public static final int DEFAULT_DUREE_SABLIER_MIN = 60;
	public static final int DEFAULT_NOMBRE_POINTS = 6;
	
	public enum Regle {
		
		TAILLE_MIN("taille-min") {
			public boolean verifier(String value) {
				return isInteger(value) && Integer.parseInt(value) >= 3;
			}

			public String getMessage() {
				return "La taille minimale d'un mot doit être de " + getDefaultValue() + " minimum";
			}
			
			public String getDefaultValue() {
				return "3";
			}
		},
		TOUR_MAX("tour-max") {
			public boolean verifier(String value) {
				return isInteger(value);
			}

			public String getMessage() {
				return "Entrez un nombre entier";
			}
			
			public String getDefaultValue() {
				return "10";
			}
		},
		SCORE_CIBLE("score-cible") {
			public boolean verifier(String value) {
				return isInteger(value);
			}

			public String getMessage() {
				return "Entrez un nombre entier";
			}
			
			public String getDefaultValue() {
				return "50";
			}
		},
		DUREE_SABLIER("duree-cible") {
			public boolean verifier(String value) {
				return isInteger(value) && Integer.parseInt(value) >= DEFAULT_DUREE_SABLIER_MIN;
			}

			public String getMessage() {
				return "Le sablier ne peut pas avoir une durée < " + DEFAULT_DUREE_SABLIER_MIN + " sec";
			}
			
			public String getDefaultValue() {
				return "180";
			}
		},
		POINTS("points") {
			public boolean verifier(String value) {
				return isIntArray(value) && value.split(",").length == DEFAULT_NOMBRE_POINTS;
			}

			public String getMessage() {
				return "Les points doivent être un ensemble de " + DEFAULT_NOMBRE_POINTS + " entiers";
			}
			
			public String getDefaultValue() {
				return "1,1,2,3,5,11";
			}
		},
		FICHIER_DES("des") {
			public boolean verifier(String value) {
				return !isEmpty(value);
			}

			public String getMessage() {
				return "Le fichier de des ne peut pas être null";
			}
			
			public String getDefaultValue() {
				return Paths.get("config", "des-4x4.csv").toString();
			}
		},
		FICHIER_DICO("dictionnaire") {
			public boolean verifier(String value) {
				return !isEmpty(value);
			}

			public String getMessage() {
				return "Le fichier dictionnaire ne peut pas être null";
			}
			
			public String getDefaultValue() {
				return Paths.get("config", "dict-fr.txt").toString();
			}
		};
		
		private final String key;
		
		private Regle(String key) {
			this.key = key;
		}

		public abstract boolean verifier(String value);

		public abstract String getMessage();

		public abstract String getDefaultValue();

		public String key() {
			return key;
		}
		
		/* Retire les espaces dans une chaîne de caractères */
		private static String noBlank(String str) {
			return str.replaceAll(" ", "");
		}
		
		/* Vérifie si une chaîne est un entier */
		private static boolean isInteger(String str) {
			return str != null && noBlank(str).matches("[+-]?\\d+(\\.\\d+)?");
		}
		
		/* Vérifie si une chaîne est un tableau d'entier */
		private static boolean isIntArray(String str) {
			return str != null && noBlank(str).matches("[0-9]+(,[0-9]+)*");
		}
		
		/* Vérifie si une chaîne est vide */
		private static boolean isEmpty(String str) {
			return str != null && noBlank(str).length() == 0;
		}
		
	}
	
	private String titre;
	private Properties prop;
	
	public Regles() {
		this("Nouvelle partie", new Properties());
	}
	
	public Regles(String title, Properties prop) {
		this.titre = title;
		this.prop = new Properties();
		String value;
		for (Regle regle : Regle.values()) {
			value = prop.getProperty(regle.key(), regle.getDefaultValue());
			this.setRegle(regle, value);
		}
	}

	public String getTitre() {
		return titre;
	}

	public void setTitre(String titre) {
		this.titre = titre;
	}

	public void setRegle(Regle regle, String value) {
		if (regle.verifier(value)) {
			prop.setProperty(regle.key(), value);
		}
		else {
			throw new BoggleException(regle.getMessage());
		}
	}

	public void setRegle(Regle regle, Path value) {
		setRegle(regle, value.toString());
	}

	public void setRegle(Regle regle, int value) {
		setRegle(regle, String.valueOf(value));
	}

	public void setRegle(Regle regle, int[] values) {
		String value = "";
		for (int i=0; i < values.length; i++) {
			value += values[i];
			if (i < values.length - 1) {
				value += ",";
			}
		}
		setRegle(regle, value);
	}

	public String getString(Regle regle) {
		String value = prop.getProperty(regle.key()).replaceAll(" ", "");
		if (regle.verifier(value)) {
			return value;
		}
		throw new BoggleException(regle.getMessage());
	}

	public int getInt(Regle regle) {
		String value = getString(regle);
		if (regle.verifier(value)) {
			return Integer.parseInt(value);
		}
		throw new BoggleException(regle.getMessage());
	}

	public int[] getIntArray(Regle regle) {
		String value = getString(regle);
		if (regle.verifier(value)) {
			String[] array = value.split(",");
			int[] values = new int[array.length];
			for (int i=0; i < values.length; i++) {
				values[i] = Integer.parseInt(array[i]);
			}
			return values;
		}
		throw new BoggleException(regle.getMessage());
	}

	public void sauvegarder() {
		Path path = Paths.get(titre);
		if (path.getParent() == null) {
			path = CONFIG_FOLDER.resolve(path);
		}
		try (BufferedWriter out = Files.newBufferedWriter(path, Charset.forName("UTF-8"))) {
			prop.store(out, null);
		} catch (IOException e) {
			throw new BoggleException("Une erreur s'est produite à l'écriture du fichier " + path + "\n" + e);
		}
	}

	public String toString() {
		return titre;
	}
	
	public String describe() {
		return prop.toString();
	}
	

	public Regles clone() {
		Regles regles = new Regles();
		regles.setTitre(titre);
		for (Regle regle : Regle.values()) {
			regles.setRegle(regle, this.getString(regle));
		}
		return regles;
	}

	public static Regles chargerRegles(Path fichier) {
		Properties prop = new Properties();
		try (BufferedReader in = Files.newBufferedReader(fichier, Charset.forName("UTF-8"))) {
			prop.load(in);
		} catch (IOException e) {
			throw new BoggleException("Une erreur s'est produite à l'ouverture du fichier " + fichier + "\n" + e);
		}
		return new Regles(fichier.getFileName().toString(), prop);
	}
	
	public static Regles chargerRegles(String fichier) {
		return chargerRegles(Paths.get(fichier));
	}
	
}
