package boggle.jeu;

import java.util.Observable;

import boggle.mots.ArbreLexical;
import boggle.mots.Grille;

/**
 * Représentation générique d'un joueur de Boggle
 */
public class Joueur extends Observable implements Comparable<Joueur> {
	
	private String nom;
	private int score;
	
	// Constructeur utilisé surtout pour l'objet Classement
	// On peut retrouver le score du joueur stocké dans un fichier
	public Joueur(String nom, int score) {
		this.nom = nom;
		this.score = score;
	}
	
	public Joueur(String nom) {
		this(nom, 0);
	}
	
	// Notifie les observeurs que le joueur a changé
	private void update() {
		setChanged();
		notifyObservers();
	}
	

	public String getNom() {
		return nom;
	}
	

	public int getScore() {
		return score;
	}
	

	public void setScore(int score) {
		this.score = score;
	}
	

	public void resetScore() {
		this.score = 0;
		update();
	}
	

	public void incScore(int n) {
		this.score += n;
		update();
	}
	

	public boolean equals(Object o) {
		Joueur j = (Joueur) o;
		return j != null && nom == j.nom;
	}
	

	public String toString() {
		return nom + " (score: " + score + ")";
	}
	

	public int compareTo(Joueur joueur) {
		return joueur.score - score;
	}
	

	public void joue(Grille grille, ArbreLexical arbre, Partie partie){};
	
	
}
