package boggle;

import java.text.Normalizer;

public final class Ascii {
	
	private Ascii() {}
	
	
	public static String normalize(String str) {
		return Normalizer.normalize(str, Normalizer.Form.NFD).replaceAll("\\p{InCombiningDiacriticalMarks}+", "");
	}

	public static String normalizeUpper(String str) {
		return normalize(str).toUpperCase();
	}

}