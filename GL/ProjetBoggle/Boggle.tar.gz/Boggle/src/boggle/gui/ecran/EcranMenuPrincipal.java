package boggle.gui.ecran;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.Font;

import javax.swing.JLabel;
import javax.swing.JPanel;

import boggle.gui.ecran.EcranManager.Bouton;

//Menu principal
public class EcranMenuPrincipal extends Ecran {
	
	public EcranMenuPrincipal() {
		super(new BorderLayout());
		
		JPanel centre = new JPanel();
		JLabel titre = new JLabel("Boggle");
		JPanel bas = new JPanel(new FlowLayout(FlowLayout.TRAILING));
		
		titre.setFont(new Font("Arial", Font.BOLD, 100));
		titre.setForeground(Color.WHITE);
		
		centre.add(titre);
		centre.setBackground(Color.lightGray);

		bas.setBackground(Color.lightGray);
		
		this.add(centre, BorderLayout.CENTER);
		this.add(bas, BorderLayout.SOUTH);
	}

	public void reload() {
		cacherBoutons();
		afficherBoutons(Bouton.JOUER, Bouton.CLASSEMENTS);
	}
	
	public void clear() {
	}
	
	public void getObject (Object o) {
	}


}
