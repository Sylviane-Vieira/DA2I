package boggle.gui.ecran;

import java.awt.BorderLayout;

import javax.swing.JOptionPane;

import boggle.BoggleException;
import boggle.gui.ecran.EcranManager.Bouton;
import boggle.gui.ecran.EcranManager.EnumEcran;
import boggle.gui.regles.JoueursPanel;
import boggle.gui.regles.ReglesPanel;
import boggle.jeu.Partie;


public class EcranNouvellePartie extends Ecran {

	private static final long serialVersionUID = 4790691387769043379L;

	private ReglesPanel reglesPanel;
	private JoueursPanel joueursPanel;
	
	public EcranNouvellePartie() {
		super(new BorderLayout());
		reglesPanel = new ReglesPanel(this);
		joueursPanel = new JoueursPanel();
		this.add(joueursPanel, BorderLayout.WEST);
		this.add(reglesPanel, BorderLayout.CENTER);
	}
	
	public void getObject (Object o) {
	}
	
	public void reload() {
		cacherBoutons();
		afficherBoutons(Bouton.MENU_PRINCIPAL);
	}
	
	public void clear() {
	}
	
	
	public void demarrer() {
		try {
			Partie partie = new Partie(reglesPanel.getReglesCourantes(), joueursPanel.getTousLesJoueurs());
			switchTo(EnumEcran.JEU, partie);
		} catch (BoggleException e) {
			JOptionPane.showMessageDialog(this, e.getMessage(), "Erreur", JOptionPane.INFORMATION_MESSAGE);
		}
	}

}
