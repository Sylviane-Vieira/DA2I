package boggle.gui.ecran;

import java.awt.Color;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTabbedPane;

import boggle.gui.classement.JClassement;
import boggle.gui.ecran.EcranManager.Bouton;
import boggle.jeu.Classement;


public class EcranClassements extends Ecran {
	
	private static final long serialVersionUID = 599000474435628090L;
	
	// Liste de tous les classements par de grille
	private List<Classement> classements;

	private JTabbedPane pane;
	
	private JPanel aucunClassement;
	
	public EcranClassements() {
		this.classements = new ArrayList<Classement>();
		this.setBackground(Color.lightGray);
		
		pane = new JTabbedPane();
		pane.setVisible(false);
		this.add(pane);
		
		JLabel info = new JLabel("Pas de classement");
		info.setForeground(Color.WHITE);
		aucunClassement = new JPanel();
		aucunClassement.setBackground(null);
		aucunClassement.add(info);
		aucunClassement.setVisible(false);
		this.add(aucunClassement);
	}

	public void reload() {
		cacherBoutons();
		afficherBoutons(Bouton.MENU_PRINCIPAL, Bouton.NOUVELLE_PARTIE);
		afficherClassements();
	}
	

	public void afficherClassements() {
		classements.addAll(Classement.listerTous());
		Iterator<Classement> it = classements.iterator();
		Classement c;
		while (it.hasNext()) {
			c = it.next();
			pane.add(c.getTitle(), new JClassement(c));
		}
		if (pane.getComponentCount() > 0) {
			pane.setVisible(true);
		}
		else {
			aucunClassement.setVisible(true);
		}
	}

	public void clear() {
		classements.clear();
		pane.removeAll();
		pane.setVisible(false);
		aucunClassement.setVisible(false);
	}
	
	public void getObject(Object o) {}

}
