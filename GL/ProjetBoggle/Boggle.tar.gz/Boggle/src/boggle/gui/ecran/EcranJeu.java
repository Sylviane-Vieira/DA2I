package boggle.gui.ecran;

import boggle.BoggleException;
import boggle.gui.ecran.EcranManager.Bouton;
import boggle.gui.partie.JPartie;
import boggle.jeu.Partie;

// Gère la partie en cours
public class EcranJeu extends Ecran {
	
	private Partie partie;

	public EcranJeu() {}

	// L'écran attend de recevoir une partie
	public void getObject (Object o) {
		if (o instanceof Partie) {
			partie = (Partie) o;
		}
		else {
			throw new BoggleException("Pas de nouvelle Partie");
		}
	}
	
	// Initialise la partie
	public void reload() {
		cacherBoutons();
		afficherBoutons(Bouton.MENU_PRINCIPAL, Bouton.NOUVELLE_PARTIE);
		this.add(new JPartie(partie));
		new Thread(partie).start();
	}
	
	// Arrête la partie en cas de fermeture
	public void clear() {
		if (partie != null && !partie.estTerminee()) {
			partie.forcerArret();
		}
		this.removeAll();
	}

}
