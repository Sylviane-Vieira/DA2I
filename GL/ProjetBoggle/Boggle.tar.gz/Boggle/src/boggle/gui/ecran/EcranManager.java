package boggle.gui.ecran;

import java.awt.BorderLayout;
import java.awt.CardLayout;
import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;

import boggle.gui.boutons.BtnMenu;


public class EcranManager extends JFrame {

	public enum Bouton {
		
		MENU_PRINCIPAL("Menu Principal", EnumEcran.MENU_PRINCIPAL),
		NOUVELLE_PARTIE("Nouvelle partie", EnumEcran.NOUVELLE_PARTIE),
		JOUER("Jouer", EnumEcran.NOUVELLE_PARTIE),
		CLASSEMENTS("Classements", EnumEcran.CLASSEMENTS);
		

		private final String nom;

		private final JButton bouton;
		
		private Bouton(String name, final EnumEcran ecran) {
			this.nom = name;
			this.bouton = new BtnMenu (new JButton(name));
			this.bouton.addActionListener(new ActionListener() {

				public void actionPerformed(ActionEvent e) {
					EcranManager.getInstance().show(ecran);
				}
				
			});
		}
		

		public void setVisible(boolean visible) {
			bouton.setVisible(visible);
		}
		

		public void cacher() {
			setVisible(false);
		}
		

		public void afficher() {
			setVisible(true);
		}
		

		public String toString() {
			return nom;
		}
		
	}
	
	public enum EnumEcran {
		
		MENU_PRINCIPAL(new EcranMenuPrincipal()),
		NOUVELLE_PARTIE(new EcranNouvellePartie()),
		JEU(new EcranJeu()),
		CLASSEMENTS(new EcranClassements());
		

		private final Ecran ecranReel;
		
		private EnumEcran(Ecran ecran) {
			this.ecranReel = ecran;
		}

		public String getLabel() {
			return name();
		}
		

		public void setObject(Object o, EnumEcran jeu2) {
			ecranReel.setObject(o, jeu2);
		}
		
	
		public void getObject(Object o) {
			ecranReel.getObject(o);
		}
		
	}
	
	public static EcranManager ecranManager;
	

	public static EcranManager getInstance() {
		if (ecranManager == null) {
			ecranManager = new EcranManager();
			ecranManager.first();
		}
		return ecranManager;
	}
	

	private CardLayout cardLayout;

	private JPanel conteneurPrincipal;

	private JPanel conteneurBoutons;
	
	private EcranManager() {
		super("Boggle");
		this.cardLayout = new CardLayout();
		this.conteneurPrincipal = new JPanel(cardLayout);
		this.conteneurBoutons = new JPanel();
		for (Bouton bouton : Bouton.values()) {
			conteneurBoutons.add(bouton.bouton);
		}
		for (EnumEcran ecran : EnumEcran.values()) {
			conteneurPrincipal.add(ecran.ecranReel, ecran.getLabel());
		}
		this.conteneurBoutons.setBackground(Color.WHITE);
		this.add(conteneurPrincipal, BorderLayout.CENTER);
		this.add(conteneurBoutons, BorderLayout.SOUTH);
	}
	
	public void first() {
		cardLayout.first(conteneurPrincipal);
		repack();
	}
	
	public void last() {
		cardLayout.last(conteneurPrincipal);
		repack();
	}
	
	public void next() {
		cardLayout.next(conteneurPrincipal);
		repack();
	}

	public void previous() {
		cardLayout.previous(conteneurPrincipal);
		repack();
	}
	
	public void show(EnumEcran ecran) {
		cardLayout.show(conteneurPrincipal, ecran.getLabel());
		repack();
	}
	
	public void cacherBoutons() {
		for (Bouton b : Bouton.values()) {
			b.cacher();
		}
	}
	
	public void cacherBoutons(Bouton... boutons) {
		for (Bouton b : boutons) {
			b.cacher();
		}
	}
	
	public void afficherBoutons() {
		for (Bouton b : Bouton.values()) {
			b.afficher();
		}
	}
	
	public void afficherBoutons(Bouton... boutons) {
		for (Bouton b : boutons) {
			b.afficher();
		}
	}
	
	public void repack() {
		this.pack();
	}
	
}
