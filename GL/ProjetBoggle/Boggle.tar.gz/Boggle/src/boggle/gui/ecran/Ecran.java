package boggle.gui.ecran;

import java.awt.FlowLayout;
import java.awt.LayoutManager;

import javax.swing.JPanel;

import boggle.gui.ecran.EcranManager.Bouton;
//import boggle.gui.ecran.EcranManager.Ecran;
import boggle.gui.ecran.EcranManager.EnumEcran;

//Gestion de l'affichage
public abstract class Ecran extends JPanel {
	
	private static final long serialVersionUID = 4088889425334087954L;
	
	public Ecran() {
		this(new FlowLayout());
	}
	
	public Ecran(LayoutManager layoutManager) {
		super(layoutManager);
	}
	
	
	public abstract void reload();
	
	
	public abstract void clear();
	
	
	public abstract void getObject (Object o);
	
	
	public void setObject (Object o, EnumEcran e) {
		e.getObject (o);
	}
	
	public void setVisible(boolean visible)	{
		super.setVisible(visible);
		if (visible) {
			reload();
		}
		else {
			clear();
		}
	}
	

	public void cacherBoutons() {
		EcranManager.getInstance().cacherBoutons();
	}
	
	public void cacherBoutons(Bouton... boutons) {
		EcranManager.getInstance().cacherBoutons(boutons);
	}
	

	public void afficherBoutons() {
		EcranManager.getInstance().afficherBoutons();
	}
	
	public void afficherBoutons(Bouton... boutons) {
		EcranManager.getInstance().afficherBoutons(boutons);
	}
	

	public void switchTo(EnumEcran ecran) {
		EcranManager.getInstance().show(ecran);
	}
	

	public void switchTo(EnumEcran jeu, Object o) {
		jeu.setObject (o, jeu);
		switchTo(jeu);
	}

}
