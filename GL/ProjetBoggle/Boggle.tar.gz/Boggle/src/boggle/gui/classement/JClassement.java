package boggle.gui.classement;

import java.util.Observable;
import java.util.Observer;

import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

import boggle.jeu.Classement;

public class JClassement extends JScrollPane implements Observer {
	
	private static final long serialVersionUID = 8994111109824949559L;
	
	private Classement classement;
	private TableClassementModel tableModel;
	
	public JClassement(Classement classement) {
		super();
		classement.addObserver(this);
		this.classement = classement;
		this.tableModel = new TableClassementModel();
		this.setViewportView(new JTable(tableModel));
	}
	
	/**
	 * Retourne le classement associé à la vue courante
	 * 
	 * @return	l'instance de Classement associée à une vue
	 */
	public Classement getClassement() {
		return this.classement;
	}
	
	/**
	 * Modèle de JTable pour la représentation graphique des instances de Classement
	 */
	private class TableClassementModel extends DefaultTableModel {
		
		private static final long serialVersionUID = -5742429842171045372L;

		public TableClassementModel() {
			super(classement.nbLignes(), 2);
			this.setColumnIdentifiers(new String[] { "Joueur", "Score" });
		}

		public Object getValueAt(int row, int col) {
			if (col == 0) {
				return classement.getJoueur(row).getNom();
			}
			return classement.getScore(row);
		}

	}
	
	// Le classement a changé, on met à jour la JTable en triant les joueurs
	public void update(Observable obs, Object o) {
		tableModel.fireTableDataChanged();
	}

}
