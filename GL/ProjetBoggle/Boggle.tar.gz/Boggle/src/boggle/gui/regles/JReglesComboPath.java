package boggle.gui.regles;

import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.io.IOException;
import java.nio.file.DirectoryStream;
import java.nio.file.Files;
import java.nio.file.Path;

import javax.swing.JComboBox;

import boggle.BoggleException;
import boggle.jeu.Regles;
import boggle.jeu.Regles.Regle;


public class JReglesComboPath extends JComboBox<Path> {
	
	private String prefixe;
	
	public JReglesComboPath(final Regles regles, final Regle regle, String prefixe) {
		super();
		this.prefixe = prefixe;
		this.addItemListener(new ItemListener() {

			public void itemStateChanged(ItemEvent e) {
				regles.setRegle(regle, (Path) e.getItem());
			}
			
		});
		recharger();
	}
	
	private void recharger() {
		this.removeAllItems();
		Path root = Regles.CONFIG_FOLDER;
		Path chemin;
		try (DirectoryStream<Path> directoryStream = Files.newDirectoryStream(root)) {
			for (Path path : directoryStream) {
				chemin = path.getFileName();
				if (chemin.toString().startsWith(prefixe)) {
					this.addItem(chemin);
				}
			}
		} catch (IOException e) {
			throw new BoggleException("Une erreur s'est produite à la lecture du dossier " + root + "\n" + e);
		}	
	}

}
