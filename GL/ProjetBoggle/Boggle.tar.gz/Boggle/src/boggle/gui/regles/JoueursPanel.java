package boggle.gui.regles;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JPanel;
import javax.swing.JTextField;

import boggle.gui.boutons.BtnBlack;
import boggle.jeu.Joueur;


public class JoueursPanel extends JPanel {
	
	public static final int JOUEUR_MAX = 5;
	
	public JoueursPanel() {
		super();
		this.setPreferredSize(new Dimension(300, 30 * JOUEUR_MAX));
		for (int i=0; i < 2; i++) {
			ajouter();
		}
		this.setBackground(Color.lightGray);
	}

	public int nbJoueurs() {
		return this.getComponentCount();
	}

	public void ajouter() {
		if (nbJoueurs() < JOUEUR_MAX) {
			this.add(new SimpleJoueurPanel());
			this.validate();
		}
	}
	
	public void supprimer(SimpleJoueurPanel joueurPanel) {
		if (nbJoueurs() > 1) {
			this.remove(joueurPanel);
			this.validate();
			this.repaint();
		}
	}
	
	public Joueur[] getTousLesJoueurs() {
		int size = nbJoueurs();
		Joueur[] joueurs = new Joueur[size];
		for(int i = 0 ; i < size; i++) {
			SimpleJoueurPanel joueurPanel = (SimpleJoueurPanel) this.getComponent(i);
			joueurs[i] = new Joueur(joueurPanel.getNomJoueur()); 
		}
		return joueurs;
	}
	
	class SimpleJoueurPanel extends JPanel {
		
		private JTextField textField;
		private JComboBox<String> comboBox;
		
		public SimpleJoueurPanel() {
			super();
			JButton moins = new BtnBlack(new JButton("-"));
			JButton plus = new BtnBlack(new JButton("+"));
			textField = new JTextField("Nom");
			textField.setPreferredSize(new Dimension(110, 25));
			
			moins.addActionListener(new ActionListener() {
	
				public void actionPerformed(ActionEvent e) {
					supprimer(SimpleJoueurPanel.this);
				}				
				
			});
			
			plus.addActionListener(new ActionListener() {
	
				public void actionPerformed(ActionEvent e) {
					ajouter();
				}
				
			});
			
			this.add(moins);
			this.add(plus);
			this.add(textField);
			this.setBackground(null);
		}
		
		public String getNomJoueur() {
			return textField.getText();
		}
		
		public String getType() {
			return (String) comboBox.getSelectedItem();
		}
	
	}
	
}
