package boggle.gui.regles;

import javax.swing.JSpinner;
import javax.swing.SpinnerNumberModel;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

import boggle.jeu.Regles;
import boggle.jeu.Regles.Regle;

public class JRegleIntSpinner extends JSpinner {
	
	public JRegleIntSpinner(final Regles regles, final Regle regle, int min, int max) {
		super(new SpinnerNumberModel(regles.getInt(regle), min, max, 1));
		this.addChangeListener(new ChangeListener() {

			public void stateChanged(ChangeEvent e) {
				regles.setRegle(regle, (int) JRegleIntSpinner.this.getValue());
			}
			
		});
	}

}
