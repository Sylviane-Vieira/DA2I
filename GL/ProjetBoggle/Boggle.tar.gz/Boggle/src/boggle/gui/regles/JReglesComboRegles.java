package boggle.gui.regles;

import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.io.IOException;
import java.nio.file.DirectoryStream;
import java.nio.file.Files;
import java.nio.file.Path;

import javax.swing.JComboBox;

import boggle.BoggleException;
import boggle.jeu.Regles;


public class JReglesComboRegles extends JComboBox<Regles> {
	
	public JReglesComboRegles(final ReglesPanel reglesPanel) {
		super();
		this.addItemListener(new ItemListener() {

			public void itemStateChanged(ItemEvent e) {
				reglesPanel.changerReglesPar((Regles) e.getItem());
			}
			
		});
		recharger();
	}
	

	public int indexOf(String titre) {
		for (int i = 0; i < getItemCount(); i++) {
			if (getItemAt(i).getTitre().equals(titre)) {
				return i;
			}
		}
		return -1;
	}

	private void recharger() {
		this.removeAllItems();
		Path root = Regles.CONFIG_FOLDER;
		try (DirectoryStream<Path> directoryStream = Files.newDirectoryStream(root)) {
			for (Path path : directoryStream) {
				if (path.getFileName().toString().startsWith("regles-")) {
					this.addItem(Regles.chargerRegles(path));
				}
			}
		} catch (IOException e) {
			throw new BoggleException("Une erreur s'est produite à la lecture du dossier " + root + "\n" + e);
		}
	}

}
