package boggle.gui.regles;

import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.nio.file.Paths;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.SwingUtilities;

import boggle.gui.boutons.BtnMenu;
import boggle.gui.ecran.EcranNouvellePartie;
import boggle.jeu.Regles;
import boggle.jeu.Regles.Regle;

//gère les règles
public class ReglesPanel extends JPanel {

	private GridBagConstraints cstr;
	
	private Regles regles;
	private JRegleIntSpinner spTailleMin, spTourMax, spScoreCible, spDureeSablier;
	private JReglesComboPath comboDes;
	private JReglesComboPath comboDico;
	
	private JReglesComboRegles charger;
	private JButton sauvegarder;
	private JButton demarrer;

	public ReglesPanel(final EcranNouvellePartie ecran) {
		super(new GridBagLayout());
		regles = new Regles();
		spTailleMin = new JRegleIntSpinner(regles, Regle.TAILLE_MIN, Regles.DEFAULT_TAILLE_MIN, 10);
		spTourMax = new JRegleIntSpinner(regles, Regle.TOUR_MAX, 1, 10);
		spScoreCible = new JRegleIntSpinner(regles, Regle.SCORE_CIBLE, 10, 500);
		spDureeSablier = new JRegleIntSpinner(regles, Regle.DUREE_SABLIER, Regles.DEFAULT_DUREE_SABLIER_MIN, 60 * 5);
		comboDes = new JReglesComboPath(regles, Regle.FICHIER_DES, "des-");
		comboDico = new JReglesComboPath(regles, Regle.FICHIER_DICO, "dict-");
		charger = new JReglesComboRegles(this);
		sauvegarder = new BtnMenu(new JButton("Sauvegarder règles"));
		demarrer = new BtnMenu(new JButton("Démarrer partie"));
		cstr = new GridBagConstraints();
		
		this.add(charger, contraintes(0, 0, 2, 1));
		this.add(sauvegarder, contraintes(1, 0, 2, 1));
		this.add(new JLabel("Taille minimale des mots"), contraintes(0, 1));
		this.add(spTailleMin, contraintes(1, 1));
		this.add(new JLabel("Nombre de tours"), contraintes(0, 2));
		this.add(spTourMax, contraintes(1, 2));
		this.add(new JLabel("Durée du sablier"), contraintes(0, 4));
		this.add(spDureeSablier, contraintes(1, 4));
		this.add(new JLabel("Des"), contraintes(0, 6));
		this.add(comboDes, contraintes(1, 6));
		this.add(new JLabel("Dictionnaire"), contraintes(0, 7));
		this.add(comboDico, contraintes(1, 7));
		this.add(demarrer, contraintes(1, 8, 2, 1));
		

		
		sauvegarder.addActionListener(new ActionListener() {

			public void actionPerformed(ActionEvent e) {
				sauvegarder();
			}
			
		});
		demarrer.addActionListener(new ActionListener() {

			public void actionPerformed(ActionEvent e) {
				final String initialText = demarrer.getText();
				demarrer.setText("Chargement...");
				SwingUtilities.invokeLater(new Runnable()  {

					public void run() {
						ecran.demarrer();
						demarrer.setText(initialText);
					}
					
				});
			}
			
		});
		
		if (charger.getItemCount() > 0) {
			changerReglesPar(charger.getItemAt(0));
		}
	}
	
	public Regles getReglesCourantes() {
		return regles;
	}
	

	public void sauvegarder() {
		String input = JOptionPane.showInputDialog(null, "Nom du fichier: (regles-", "NouvellesRegles");
		if (input != null) {
			if (input.trim().length() == 0) {
				JOptionPane.showMessageDialog(null, input + " n'est pas un nom de fichier correct.", "Erreur", JOptionPane.INFORMATION_MESSAGE);
			}
			else {
				String fichier = "regles-" + input;
				if (!fichier.endsWith(".config")) {
					fichier += ".config";
				}
				regles.setTitre(fichier);
				regles.sauvegarder();
				int exists = charger.indexOf(fichier);
				Regles clone = regles.clone();
				if (exists == -1) {
					charger.addItem(clone);
					charger.setSelectedItem(clone);
				}
				else {
					int confirm = JOptionPane.showConfirmDialog(null,
							"Le fichier " + fichier + " existe déjà. Souhaitez-vous l'écraser ?",
							"Attention",
							JOptionPane.YES_OPTION);
					if (confirm == JOptionPane.YES_OPTION) {
						charger.removeItemAt(exists);
						charger.insertItemAt(clone, exists);
						charger.setSelectedIndex(exists);
					}
				}
			}
		}
	}
	
	// Définit des contraintes d'affichage
	private GridBagConstraints contraintes(int gridx, int gridy) {
		return contraintes(gridx, gridy, 1, 1);
	}
	
	// Définit des contraintes d'affichage
	private GridBagConstraints contraintes(int gridx, int gridy, int gridwidth, int gridheight) {
		cstr.gridx = gridx;
		cstr.gridy = gridy;
		cstr.gridwidth = gridwidth;
		cstr.gridheight = gridheight;
		cstr.insets = new Insets(7, 15, 15, 0);
		cstr.anchor = GridBagConstraints.BASELINE_LEADING;
		return cstr;
	}

	public void changerReglesPar(Regles item) {
		spTailleMin.setValue(item.getInt(Regle.TAILLE_MIN));
		spTourMax.setValue(item.getInt(Regle.TOUR_MAX));
		spScoreCible.setValue(item.getInt(Regle.SCORE_CIBLE));
		spDureeSablier.setValue(item.getInt(Regle.DUREE_SABLIER));
		comboDes.setSelectedItem(Paths.get(item.getString(Regle.FICHIER_DES)));
		comboDico.setSelectedItem(Paths.get(item.getString(Regle.FICHIER_DICO)));
	}
	

}
