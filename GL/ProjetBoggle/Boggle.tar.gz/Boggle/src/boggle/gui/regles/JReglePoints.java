package boggle.gui.regles;

import java.awt.FlowLayout;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JPanel;
import javax.swing.JSpinner;
import javax.swing.SpinnerNumberModel;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

import boggle.jeu.Regles;
import boggle.jeu.Regles.Regle;

public class JReglePoints extends JPanel {
	
	private int[] points;
	private List<JReglePointsSpinner> spinners;
	
	public JReglePoints(Regles regles) {
		super(new FlowLayout(FlowLayout.LEADING));
		this.points = new int[Regles.DEFAULT_NOMBRE_POINTS];
		this.spinners = new ArrayList<JReglePointsSpinner>();
		
		JReglePointsSpinner sp;
		for (int i=0; i < points.length; i++) {
			sp = new JReglePointsSpinner(regles, i);
			spinners.add(sp);
			this.add(sp);
		}
	}
	
	public void setValues(int[] values) {
		for (int i=0; i < points.length; i++) {
			spinners.get(i).setValue(values[i]);
		}
	}
	
	class JReglePointsSpinner extends JSpinner {
		
		public JReglePointsSpinner(final Regles regles, final int idxPoint) {
			super(new SpinnerNumberModel(1, 1, 20, 1));
			this.addChangeListener(new ChangeListener() {

				public void stateChanged(ChangeEvent e) {
					points[idxPoint] = (int) JReglePointsSpinner.this.getValue();
					regles.setRegle(Regle.POINTS, points);
				}
				
			});
		}
		
	}

}
