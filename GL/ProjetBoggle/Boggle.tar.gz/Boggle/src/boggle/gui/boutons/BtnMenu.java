package boggle.gui.boutons;

import java.awt.Color;

import javax.swing.JButton;

/**
 * Définition d'un bouton plat type Material Design pour le menu.
 */
public class BtnMenu extends BtnDeco {

	private static final long serialVersionUID = 8813538990842453141L;

	public BtnMenu(JButton bouton) {
		super(bouton);
		this.setBackground(Color.WHITE);
		this.setForeground(Color.DARK_GRAY);
	}

}
