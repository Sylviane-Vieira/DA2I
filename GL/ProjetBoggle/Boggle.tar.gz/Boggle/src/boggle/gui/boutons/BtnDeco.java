package boggle.gui.boutons;

import javax.swing.JButton;

/**
 * Ajoute une décoration sur un JButton.
 */
public class BtnDeco extends JButton {
	
	private static final long serialVersionUID = 772827254096143798L;

	public BtnDeco (JButton bouton) {
		super(bouton.getText());
	}

}
