package boggle.gui.boutons;

import java.awt.Color;

import javax.swing.JButton;


public class BtnFocusOff extends BtnDeco {

	private static final long serialVersionUID = 8813538990842453141L;

	public BtnFocusOff(JButton bouton) {
		super(bouton);
		this.setBackground(Color.WHITE);
		this.setForeground(Color.BLACK);
		this.setFocusable(false);
	}

}
