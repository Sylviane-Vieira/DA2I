package boggle.gui;

import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.SwingUtilities;

import boggle.gui.ecran.EcranManager;


public class Lanceur {
	
	public static JFrame frame;
	
	public static void main(String[] args) {
		SwingUtilities.invokeLater(new Runnable()  {
			public void run() {
				final JFrame frame = EcranManager.getInstance();
				frame.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
				frame.pack();
				frame.setLocationRelativeTo(null);
				frame.setVisible(true);
				frame.addWindowListener(new WindowAdapter() {
					
					public void windowClosing(WindowEvent e) {
						int option = JOptionPane.showConfirmDialog(frame.getContentPane(),
								"Quitter le jeu ?",
								"Quitter",
								JOptionPane.YES_OPTION);
						if (option == JOptionPane.YES_OPTION) {
							System.exit(0);
						}
					}
					
				});
			}
		});
	}

}
