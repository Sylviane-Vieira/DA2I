
package boggle.mots ;

import java.io.IOException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;
import java.util.Scanner;

import boggle.Ascii;
import boggle.BoggleException;

/** La classe ArbreLexical permet de stocker de façon compacte et
 * d'accéder rapidement à un ensemble de mots.*/
public class ArbreLexical {
    public static final int TAILLE_ALPHABET = 26 ;
    private boolean estMot ; // vrai si le noeud courant est la fin d'un mot valide
    private ArbreLexical[] fils = new ArbreLexical[TAILLE_ALPHABET] ; // les sous-arbres
    
    /** Crée un arbre vide (sans aucun mot) */
    public ArbreLexical() {
        // à compléter
    }

	private int indexOf(char lettre) {
		return lettre - 'A';
	}
	
	private char charAt(int i) {
		return (char) (i + 'A');
	}

	public boolean estMot() {
		return estMot ;
	}
	

    /** Place le mot spécifié dans l'arbre
     * @return <code>true</code> si le mot a été ajouté,
     * <code>false</code> sinon*/
	public boolean ajouter(String word) {
		String normalized = Ascii.normalizeUpper(word);
		// On ajoute le mot s'il est entièrement en majuscule et qu'il a la même taille que le mot de départ
		return normalized.matches("[A-Z]+") && normalized.length() == word.length() && ajouterNorme(normalized);
	}

    /**Normalise le mot en ASCII*/
	private boolean ajouterNorme(String word) {
		if (word.length() == 0) {
			estMot = true;
			return true;
		}
		char c = word.charAt(0);
		int i = indexOf(c);
		if (fils[i] == null) {
			fils[i] = new ArbreLexical();
		}
		return fils[i].ajouterNorme(word.substring(1));
	}

    /** Teste si l'arbre lexical contient le mot spécifié.
    @return <code>true</code> si <code>o</code> est un mot
    (String) contenu dans l'arbre, <code>false</code> si
    <code>o</code> n'est pas une instance de String ou si le mot
    n'est pas dans l'arbre lexical. */
	public boolean contient(String word) {
		if (word.length() == 0) {
			return estMot();
		}
		char c = Character.toUpperCase(word.charAt(0));
		ArbreLexical noeud = fils[indexOf(c)];
		return noeud != null && noeud.contient(word.substring(1));
	}
    /** Ajoute à la liste <code>resultat<code> tous les mots de
     * l'arbre commençant par le préfixe spécifié. 
     * @return <code>true</code> si <code>resultat</code> a été
     * modifié, <code>false</code> sinon.*/
	public boolean motsCommencantPar(String prefixe, List<String> resultat) {
		int niveau = 0;
		ArbreLexical arbreFils = this;
		while (niveau < prefixe.length()) {
			arbreFils = arbreFils.fils[indexOf(prefixe.charAt(niveau))];
			if (arbreFils == null) {
				return false;
			}
			niveau++;
		}
		return arbreFils.motsCommencantPar(prefixe, niveau, resultat);
	}

    /** Ajoute à la liste <code>resultat<code> tous les mots de
     * l'arbre commençant par le préfixe spécifié. 
     * @return <code>true</code> si <code>resultat</code> a été
     * modifié, <code>false</code> sinon.*/
	private boolean motsCommencantPar(String prefixe, int niveau, List<String> resultat) {
		if (this.estMot()) {
			resultat.add(prefixe);
		}
		for (int i=0; i < fils.length; i++) {
			if (fils[i] == null) {
				continue;
			}
			fils[i].motsCommencantPar(prefixe + charAt(i), niveau + 1, resultat);
		}
		return resultat.size() > 0;
	}
	
    /** Crée un arbre lexical qui contient tous les mots du fichier
     * spécifié. */
	public static ArbreLexical lireMots(String fichier) {
		return lireMots(Paths.get(fichier));
	}
	
    /** Crée un arbre lexical qui contient tous les mots du fichier
     * spécifié. */
	public static ArbreLexical lireMots(Path fichier) {
		ArbreLexical arbre = new ArbreLexical();
		try (Scanner sc = new Scanner(fichier)) {
			while (sc.hasNextLine()) {
				arbre.ajouter(sc.nextLine());
			}
		} catch (IOException e) {
			throw new BoggleException("Impossible de créer un arbre avec le fichier " + fichier + "\n" + e);
		}
		return arbre;
	}
	
}