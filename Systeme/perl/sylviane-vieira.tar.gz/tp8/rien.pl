#!/usr/bin/perl

use strict;
use warnings;
use Socket;


  print "Début du processus de pid ", $$, "\n";
  sleep(3);
  print "Fin du processus de pid ", $$, "\n";
